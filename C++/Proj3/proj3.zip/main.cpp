//-----------------------------------------------------------
// CS 215-401 – Project 3
//-----------------------------------------------------------
// Author: Chase Karlen
// Date: 11-15-2019
// Description: An application that will allow the user to register students for courses at a university
// Assistance: I did not receive any help on this program.
//-----------------------------------------------------------

#include <iostream>
#include "userint.h"

int main() {
    // create the app and start it!
    userint x;
    x.go();
    system("pause");
    return 0;
}
